create FUNCTION fun_splitstr(p_string IN VARCHAR2, p_delimiter IN VARCHAR2)
RETURN VARCHAR2
IS
v_length NUMBER;
v_start NUMBER := 1;
v_index NUMBER;
result varchar2(200);
BEGIN
    v_length := LENGTH(p_string);
    result := '';
    WHILE(v_start <= v_length)
    LOOP
        v_index := INSTR(p_string, p_delimiter, v_start);
        IF v_index = 0
        THEN
            result := result || SUBSTR(p_string, v_start);
            v_start := v_length + 1;
        ELSE
            result := result || SUBSTR(p_string, v_start, v_index - v_start);
            v_start := v_index + 1;
        END IF;
    END LOOP;
    RETURN result;
END;


