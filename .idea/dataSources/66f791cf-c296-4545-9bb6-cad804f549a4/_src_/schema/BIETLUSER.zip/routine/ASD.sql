create procedure asd(a in  varchar2,
                                b out varchar2) is
begin
  b := a;
end asd;
