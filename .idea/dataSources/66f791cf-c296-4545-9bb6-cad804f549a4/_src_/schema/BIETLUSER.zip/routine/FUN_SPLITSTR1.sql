create FUNCTION           fun_splitstr1(p_string IN VARCHAR2, p_delimiter IN VARCHAR2)
RETURN VARCHAR2
IS
v_length NUMBER;
v_start NUMBER := 1;
v_index NUMBER;
result varchar2(200);
delete_sql varchar2(2000);
p_string_1 varchar2(1000);
BEGIN
  	p_string_1:=substr(p_string,2,length(p_string));
    delete_sql := '';
    v_length := LENGTH(p_string_1);
    result := '';
    WHILE(v_start <= v_length)
    LOOP
        v_index := INSTR(p_string_1, p_delimiter, v_start);
          IF v_index = 0
          THEN
              result := SUBSTR(p_string_1, v_start);
              v_start := v_length + 1;
              delete_sql := delete_sql || 'and a.'||result||'=b.'||result||chr(10);
          ELSE
              result := SUBSTR(p_string_1, v_start, v_index - v_start);
              v_start := v_index + 1;
              delete_sql := delete_sql || 'and a.'||result||'=b.'||result||chr(10);
          END IF;
    END LOOP;
    select 'where'||substr(delete_sql,4,length(delete_sql)) into delete_sql from dual;
    
    RETURN delete_sql;
END;


