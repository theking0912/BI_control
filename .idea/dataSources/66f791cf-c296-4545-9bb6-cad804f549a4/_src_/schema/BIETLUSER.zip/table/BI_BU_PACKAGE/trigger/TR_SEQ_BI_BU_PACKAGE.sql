create trigger TR_SEQ_BI_BU_PACKAGE
	before insert
	on BI_BU_PACKAGE
	for each row
declare
  nextid number;
begin
  IF :new.PACKAGE_ID IS NULL or :new.PACKAGE_ID=0 THEN
    select SEQ_BI_BU_PACKAGE.nextval
    into nextid
    from sys.dual;
    :new.PACKAGE_ID:=nextid;
  end if;
end TR_SEQ_BI_BU_PACKAGE;
