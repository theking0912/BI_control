create trigger TR_SEQ_BI_JOB
	before insert
	on BI_JOB
	for each row
declare
  nextid number;
begin
  IF :new.JOB_ID IS NULL or :new.JOB_ID=0 THEN
    select SEQ_BI_JOB.nextval
    into nextid
    from sys.dual;
    :new.JOB_ID:=nextid;
  end if;
end TR_SEQ_BI_JOB;
