create trigger TR_SEQ_BI_INIT_EXPORT
	before insert
	on BI_INIT_EXPORT
	for each row
declare
  nextid number;
begin
  IF :new.TABLE_ID IS NULL or :new.TABLE_ID=0 THEN
    select SEQ_BI_INIT_EXPORT.nextval
    into nextid
    from sys.dual;
    :new.TABLE_ID:=nextid;
  end if;
end TR_SEQ_BI_INIT_EXPORT;
